package com.example.bss.ui.dashboard

import androidx.lifecycle.ViewModel

class DashboardViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
